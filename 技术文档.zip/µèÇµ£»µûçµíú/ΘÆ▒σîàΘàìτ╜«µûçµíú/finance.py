# -*- coding:utf-8 -*-

import hmac
import json
from hashlib import sha1
from urllib import urlencode
import time


APP_ID = 'goldgj'
APP_SECRET = 'Sni4dk'


def signature(params, apiSecret):
    if 'sign' in params.keys():
        params.pop('sign')
    params = sorted(params.items())
    message = urlencode(params).encode('utf-8')
    return hmac.new(apiSecret, message, sha1).digest().encode('hex')

def gen(symbol, address_to, txid, amount, confirm, is_mining=0, timestamp=int(time.time())):
    params = {
        "app_id": APP_ID,
        "timestamp": timestamp,
        "symbol": symbol,
        "address_to": address_to,
        "txid": txid,
        "amount": amount,
        "confirm": confirm,
        "is_mining": is_mining
    }
    params['sign'] = signature(params, APP_SECRET)
    return json.dumps(params)

def gen1(symbol,trans_id,  address_to, txid, amount, confirm, real_fee, timestamp=int(time.time())):
    params = {
        "app_id": APP_ID,
        "timestamp": timestamp,
        "symbol": symbol,
        "trans_id": trans_id,
        "address_to": address_to,
        "txid": txid,
        "amount": amount,
        "confirm": confirm,
        "real_fee": real_fee
    }
    params['sign'] = signature(params, APP_SECRET)
    return json.dumps(params)

#curl -i -X POST -H "Content-type:application/json" -d '' http://172.31.39.82:8151/finance/depositNotify
#curl -i -X POST -H "Content-type:application/json" -d '' http://172.31.114.202:8085/finance/withdrawNotify
#curl -i -X POST -H "Content-type:application/json" -d '' http://172.31.8.162:8151/finance/withdrawNotify


jsonstr = gen('mex', '0x129efac7da21a97d19deef368ce6a0c147a99ea0', '0x5a7b49fd1c52c1cc45262606d69699617b16915e6fca08e4a5c6041e6a60eaac', '468000', 721)
print(jsonstr)


{"amount": "1998", "confirm": 36839, "is_mining": 0, "timestamp": 1517384834, "symbol": "ascs", "sign": "f1b97f860b87662db2e049e638f1923c8f9bd828", "app_id": "tokencan", "address_to": "0xb22bf35399b0b66a7201e6dec52a5917c7c76db5", "txid": "0xc608e18b1b89f13f5dbe514e9a371b76973ac6b133e43bde0890bcb2a6bc300a"}


{"amount": 0.259559, "address_to": "0x537651b69dd94d0d1784cd29cfd0c9ae53eeaf3d", "confirm": 150, "timestamp": 1517800211, "symbol": "eth", "sign": "7f00489db07ddb45fe5c2e6364630b5df789bed7", "real_fee": 0.0001, "app_id": "zhongying", "trans_id": 5, "txid": "0x15990d3e83dc7e1336ff10a2617da60dd9e12c0ae4afa1749889a895e30e4961"}



