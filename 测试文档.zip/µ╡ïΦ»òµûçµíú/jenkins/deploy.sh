#!/bin/sh

# -------------------------------------------------------------------------------
# Filename:    scm.sh
# Date:        2018/04/19
# Author:      lishipeng
# Description: 部署环境
# -------------------------------------------------------------------------------



###############################函数名称列表###################################
#func_echo()
#func_trim()



############################### 函数列表 ####################################
function func_echo()
{
	local level="$1"
	local msg="$2"
	
	case $level in
		error)		echo -e "[ERROR] ${msg}";;
		warn)		echo -e "[WARN] ${msg}";;
		info)		echo -e "[INFO] ${msg}";;
		notice)		echo -e "[NOTICE] ${msg}";;
		debug)		echo -e "[DEBUG] ${msg}";;
		*)			echo "${msg}";;
	esac
}

#func_trim()
#功能说明:  删除参数的空格和特殊符号，例如无宽度空格
#参数说明: 
#	$1:string
#使用方法:
#	func_trim " level " 
function func_trim()
{
	# 删除无宽度字符，参考：http://blog.csdn.net/qq_28018283/article/details/54136480
	echo "$1" | sed 's;^[ ]*\(.*[^ ]\)[ ]*$;\1;' | sed 's/\xe2\x80\x8a//g' | sed 's/\xe2\x80\x8b//g' | sed 's/\xe2\x80\x8c//g' | sed 's/\xe2\x80\x8d//g'
}

# check
function func_check()
{
	if [[ $? -ne 0 ]];then
		func_echo "error" "$1"
		exit 1
	fi
}

function func_process()
{

	if [[ $# == 1 ]];then
		local local_dev_branch=$1
	else
		local local_dev_branch=$dev_branch
	fi

	#清除修改文件
	git clean -df
	git checkout .
	if [[ $? -ne 0 ]];then
		git reset --hard
	fi

	#pull最新代码
	git fetch
	git checkout ${local_dev_branch}
	func_check "当前分支不存在，请检查分支号是否正确"

	git pull origin ${local_dev_branch}
	func_check "在${SRC_PATH}/${module_name}目录下，执行：git pull origin master 失败！，分支有问题，检查分支和${SRC_PATH}/${module_name}目录下的git状态，然后重新部署！"

	git pull origin master
	func_check "在${SRC_PATH}/${module_name}目录下，执行：git pull origin master 失败！，合并master有冲突，请rd手动合并最新的master到分支"

}


#处理 parent 和 config 模块的代码
function func_process_config()
{
	cd ${SRC_PATH}/exchange-parent
	git reset --hard
	git clean -df
	git fetch
	git checkout ${parent_dev_branch}
	func_check "exchange-parent checkout ${parent_dev_branch} 失败"
	git pull origin ${parent_dev_branch}
	func_check "exchange-parent pull ${parent_dev_branch} 失败"

	cd ${SRC_PATH}/exchange-config
	git reset --hard
	git clean -df
	git fetch
	git checkout ${config_dev_branch}
	func_check "exchange-config checkout ${config_dev_branch} 失败"
	git pull origin ${config_dev_branch}
	func_check "exchange-config pull ${config_dev_branch} 失败"

}

#处理所有模块的分支
function func_process_all()
{
	if [[ ${refer_modules_branch} ]]; then
		refer_modules_branch=$(func_trim "$refer_modules_branch")
	else
		refer_modules_branch=${dev_branch}
	fi

	eval func_process_config ${debug_postfix}

	if [[ "X${is_related_parent}" != "Xfalse" ]]; then

		func_echo "notice" "读取所有模块，开始处理！"
		#获取代码目录下的所有已经存在的模块（刨去 parent 和 config 的模块）
		all_modules=`ls -l ${SRC_PATH} | grep ^d | awk '{print $9}' | grep -v "parent" | grep -v "config" | \
		grep -v "web" | grep -v "job" | grep -v "api" | grep -v "exchange-new" `

		#循环处理所有的模块，如果 jenkins 的refer_modules有传入这个模块，则把分支切换成开发分支。如果没有传，则默认处理为 master
		for m in ${all_modules[*]}; do
			cd ${SRC_PATH}/${m}
			if [[ ${refer_modules[@]} =~ ${m} ]] || [[ ${m} == ${module_name} ]]; then
				func_echo "notice" "开始处理模块:${m} is_related: yes ,模块切换分支：${refer_modules_branch} ，\
				如果失败，请检查此分支是否存在 or 分支合并master有冲突！"
				eval func_process ${refer_modules_branch} ${debug_postfix}
			else
				func_echo "notice" "开始处理模块:${m} is_related: no ,模块切换分支：master"
				eval func_process master ${debug_postfix}
			fi
		done
	fi

	# 处理当前模块
	cd ${SRC_PATH}/${module_name}
	func_check "工作目录不存在，请检查部署机器的${SRC_PATH}/${module_name}目录！"
	func_echo "notice" "开始处理模块:${module_name} ,模块切换分支：${dev_branch}，如果失败，请检查此分支是否存在 or 分支合并master有冲突！"
	eval func_process ${debug_postfix}
}

func_set_version()
{
	if [[ "X${is_related_parent}" == "Xfalse" ]]; then
		cd ${SRC_PATH}/${module_name}
		${MAVEN_BIN} versions:set -DnewVersion="${version_number}"
	else
		cd ${SRC_PATH}/exchange-parent
		func_echo "debug" "exe: ${MAVEN_BIN} -N versions:update-child-modules"
		${MAVEN_BIN} -N versions:update-child-modules

		func_echo "debug" "exe: ${MAVEN_BIN} versions:set -DnewVersion=${version_number}"
		${MAVEN_BIN} versions:set -DnewVersion="${version_number}"

		func_echo "debug" "exe: ${MAVEN_BIN} -N versions:update-child-modules"
		${MAVEN_BIN} -N versions:update-child-modules
	fi
}

func_build_config()
{

	cd ${SRC_PATH}/exchange-config

	${MAVEN_BIN} versions:set -DnewVersion="${version_number}"
	$MAVEN_BIN clean install -Dmaven.test.skip=true -P "${module_name}-${env}"
	func_check "exchange-config模块，执行：maven install 失败！请检查！"

}

func_mvn_install()
{
	if [[ "X${is_related_parent}" == "Xfalse" ]]; then
		cd ${SRC_PATH}/${module_name}
		$MAVEN_BIN clean package -Dmaven.test.skip=true
		func_check "maven package 失败！请检查！"
	else
		cd ${SRC_PATH}/exchange-parent
		# ${MAVEN_BIN} -N versions:update-child-modules
		# func_check "maven update-child-modules 失败！请检查！"
		$MAVEN_BIN clean install -Dmaven.test.skip=true -pl  ../${module_name} -am
		func_check "maven install 失败！请检查！"
	fi

	mkdir -p ${DEPOSIT_PATH}
	cp ${SRC_PATH}/${module_name}/target/${war_name}.war ${DEPOSIT_PATH}/
}

func_stop_tomcat()
{
	func_echo "notice" "执行：ps -ef|grep tomcat-${who}-${war_name}|grep -v 'grep'|grep 'java'|awk {'print $2'}|xargs kill -9"
	ps -ef|grep "tomcat-${who}-${war_name}"|grep -v 'grep'|grep 'java'|awk {'print $2'}|xargs kill -9
	if [[ $? -ne 0 ]];then
		func_echo "warn" "没有此TOMCAT进程，请检查是否有异常！"
	fi
}

func_start_local_tomcat()
{
	func_echo "notice" "sleep 5"
	sleep 5

	func_echo "notice" "执行：cd ${TOMCAT_BIN_PATH} && sh startup.sh"
	cd ${TOMCAT_BIN_PATH} && nohup sh startup.sh &
	func_check "TOMCAT启动失败，请检查！"
	func_check_local_tomcat
}

func_check_local_tomcat()
{
	#${TOMCAT_BIN_PATH}/startup.sh
	func_echo "notice" "begin check : sleep 10"
	sleep 10

	func_echo "notice" "检查tomcat进程是否存在"
	func_echo "notice" "ps -ef|grep 'tomcat-${who}-${war_name}'|grep -v 'grep'"
	r=`ps -ef|grep "tomcat-${who}-${war_name}"|grep -v 'grep'`
	if [[ ${r}} ]];then
		func_echo "notice" "TOMCAT启动成功！"
	else
		func_echo "error" "无 tomcat 进程，TOMCAT启动失败，请检查！"
		exit 1
	fi
}

func_del_local_war()
{
	func_echo "notice" "删除${TOMCAT_PATH}下的旧war包和解压文件"
	func_echo "notice" "开始执行：rm -rf ${TOMCAT_PATH}/${war_name}"
	func_echo "notice" "开始执行：rm -rf ${TOMCAT_PATH}/${war_name}.war"
	rm -rf ${TOMCAT_PATH}/${war_name}
	rm -rf ${TOMCAT_PATH}/${war_name}.war
}

func_cp_local_war()
{
	func_echo "notice" "复制${DEPOSIT_PATH}最新war包到TOMCAT_PATH"
	func_echo "notice" "开始执行: cp ${DEPOSIT_PATH}/${war_name}.war ${TOMCAT_PATH}"
	cp ${DEPOSIT_PATH}/${war_name}.war ${TOMCAT_PATH}
	func_check "cp失败，请检查！"
}


function func_scm()
{
	func_echo "notice" "exe: func_scm"
	cd ${SRC_PATH}
	func_check "工作目录${SRC_PATH}不存在!"
	func_process_all
	func_echo "notice" "done: func_scm"
}

function func_build()
{
	func_echo "notice" "exe: func_build"

	func_echo "notice" "exe: func_build_config"
	eval func_build_config ${debug_postfix}


	func_echo "notice" "exe: func_set_version"
	eval func_set_version ${debug_postfix}

	func_echo "notice" "exe: func_mvn_install"
	eval func_mvn_install ${debug_postfix}

	func_echo "notice" "done: func_build"
}

function func_deploy()
{
	func_echo "notice" "exe: func_deploy"
	if [[ "X${env}" == "Xprod" ]] ; then
		echo "上线，只打包，不部署tomcat！"
	else
		func_stop_tomcat
		func_del_local_war
		func_cp_local_war
		func_start_local_tomcat
	fi
	func_echo "notice" "done: func_deploy"
}





############################### 全局变量 ###################################
func_echo "info" "[+] `date +'%H:%M:%S'` info(@$LINENO): current time `date +"%Y/%m/%d %H:%M:%S"`"
d=`date +"%Y-%m-%d_%H%M"`
source /etc/profile

#代码存放目录
SCIRPT_PATH="$(cd "$(dirname "$0")"; pwd)"


############## Jenkins变量 ##############
module_name=$(func_trim "$module_name")
if [[ ${module_name} == "exchange-new" ]]; then
	war_name="exchange-web"
elif [[ ${module_name} == "exchange-finance" ]]; then
	war_name="finance"
else
	war_name=${module_name}
fi

dev_branch=$(func_trim "$dev_branch")
env=$(func_trim "$env")
refer_modules=$(func_trim "$refer_modules")

#是否依赖parent，如果没有，不需要指定此参数即可，finance、kline-web、schedule-web
if [[ ${module_name} == "exchange-finance" ]] || [[ ${module_name} == "kline-web" ]] || [[ ${module_name} == "schedule-web" ]]; then
	is_related_parent="false"
fi

if [[ "X${debug}" == "X" ]]; then
	debug_postfix=">/dev/null 2>&1"
fi


############## 客户自有变量 ##############
who="upex"
parent_dev_branch="upex-client"
config_dev_branch="master"

HOME_PATH="/home/work"
SRC_PATH="${HOME_PATH}/source/jenkins/${who}"
# build_type="java"
version_number="0.0.1"
MAVEN_BIN="${HOME_PATH}/local/maven/bin/mvn"

if [[ "X${env}" == "Xprod" ]] || [[ "X${env}" == "Xsbox" ]]; then
	version_number="${version_number}"
else
	version_number="${version_number}-SNAPSHOT"
fi


ROOT_DEPOSIT_PATH="${HOME_PATH}/projects"
DEPOSIT_PATH="${ROOT_DEPOSIT_PATH}/exchange_build/${who}/${module_name}/${env}/${d}"
TOMCAT_PATH="/usr/local/chainup/tomcat-${who}-${war_name}/webapps"
TOMCAT_BIN_PATH="/usr/local/chainup/tomcat-${who}-${war_name}/bin"



############################### 开始处理 ###################################

if [[ $is_skip_scm != true ]]; then
	func_scm
fi
if [[ $is_skip_build != true ]]; then
	func_build
fi
if [[ $is_skip_deploy != true ]]; then
	func_deploy
fi



func_echo "notice" "################################### ALL DONE ~ ###################################"
